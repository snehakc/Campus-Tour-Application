package com.skmapstutorial.Application.Activities;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.appindexing.Thing;
import com.google.android.gms.common.api.GoogleApiClient;
import com.skmapstutorial.Application.Fragments.Gallery;
import com.skmapstutorial.Application.Model.Building;
import com.skmapstutorial.Application.Model.University;
import com.skmapstutorial.Application.SKMapsApplication;
import com.skmapstutorial.R;
import com.skobbler.ngx.SKCoordinate;
import com.skobbler.ngx.map.SKAnimationSettings;
import com.skobbler.ngx.map.SKAnnotation;
import com.skobbler.ngx.map.SKCoordinateRegion;
import com.skobbler.ngx.map.SKMapCustomPOI;
import com.skobbler.ngx.map.SKMapPOI;
import com.skobbler.ngx.map.SKMapSurfaceListener;
import com.skobbler.ngx.map.SKMapSurfaceView;
import com.skobbler.ngx.map.SKMapViewHolder;
import com.skobbler.ngx.map.SKPOICluster;
import com.skobbler.ngx.map.SKPolyline;
import com.skobbler.ngx.map.SKScreenPoint;
import com.skobbler.ngx.navigation.SKNavigationManager;
import com.skobbler.ngx.routing.SKRouteManager;

import java.util.ArrayList;
import java.util.List;

import static android.view.View.GONE;

public class VirtualTourActivity extends AppCompatActivity implements SKMapSurfaceListener {
    ArrayList<SKAnnotation> buildingAnnotations;
    University university;
    Button startVirtualTourButton;
    TextView buildingName;
    static int tag =0;
    SKMapViewHolder mapHolder;
    SKMapSurfaceView mapView;

    Dialog waitingForCurrentLocation;
    ProgressDialog fetchingLocation;

    public Dialog getWaitingForCurrentLocation() {
        return waitingForCurrentLocation;
    }

    public void setWaitingForCurrentLocation(Dialog waitingForCurrentLocation) {
        this.waitingForCurrentLocation = waitingForCurrentLocation;
    }

    public ProgressDialog getFetchingLocation() {
        return fetchingLocation;
    }

    public void setFetchingLocation(ProgressDialog fetchingLocation) {
        this.fetchingLocation = fetchingLocation;
    }

    public VirtualTourActivity() {


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        university = SKMapsApplication.getUniversity();
        setContentView(R.layout.activity_virtual_tour);
        SKMapsApplication.setActiveActivity(2);
        SKMapsApplication.setVirtualTourActivity(this);
        waitingForCurrentLocation = new Dialog(this);
        fetchingLocation = new ProgressDialog(this );
       // SKNavigationManager.getInstance().stopNavigation();

        startVirtualTourButton = (Button) findViewById(R.id.start_virtual_tour_button);
        mapHolder = (SKMapViewHolder) findViewById(R.id.virtual_tour_map_surface_holder);
        mapHolder.setMapSurfaceListener(this);
        mapView = mapHolder.getMapSurfaceView();
        buildingName = (TextView) findViewById(R.id.virtual_tour_activity_building_name);
        buildingName.setText(university.getUniversityName());
        startVirtualTourButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startVirtualTourButton.setText("Continue");
                startVirtualTour();

            }
        });
    }

    public void startVirtualTour(){

        if(tag >= university.getBuildings().size()){
            addPlolyLine(university.getTourPath());
            SKCoordinateRegion universityRegion = new SKCoordinateRegion(university.getUniversityLocation(),15.5f);
            mapView.changeMapVisibleRegion(universityRegion,true);
            //mapView.zoomInAt(mapView.coordinateToPoint(university.getUniversityLocation()));
            Toast.makeText(this, "Tour Finished Calculating your total activity", Toast.LENGTH_SHORT).show();
            buildingName.setText("Tour Completed Successfully!!");
            tag = 0;
            startVirtualTourButton.setVisibility(View.GONE);
        }
        else {
            mapView.setZoom(SKMapSurfaceView.MINIMUM_ZOOM_LEVEL);
            buildingName.setText(university.getBuildings().get(tag).getBuildingName());
            mapView.animateToLocation(university.getBuildings().get(tag).getBuildingCoordinates(), 1000);
           if(tag > 0)
            addPolyLineBetweenBuildings();
            tag++;
        }
    }

    public void addPlolyLine(List<SKCoordinate> tourPath) {

        SKPolyline tourRoute = new SKPolyline();
        tourRoute.setNodes(tourPath);
        tourRoute.setColor((new float[]{0f, 0f, 1f, 0.9f}));
        mapView.addPolyline(tourRoute);
    }

    public void addPolyLineBetweenBuildings(){
      SKCoordinate  currentBuildingCoordinates = university.getBuildings().get(tag).getBuildingCoordinates();
        System.out.println("Current Building Coordinates: "+ currentBuildingCoordinates.toString());

        ArrayList<SKCoordinate> tourPath = university.getTourPath();
        int positionInCampusTour= tourPath.size() -1 ;
        for(int i=0;i<tourPath.size();i++){
            System.out.println("Current building : "+currentBuildingCoordinates.toString()+" path's coordinate: "+tourPath.get(i).toString()+" are they equal? "+currentBuildingCoordinates.toString().equals(tourPath.get(i).toString()));
            if(currentBuildingCoordinates.toString().equals(tourPath.get(i).toString())){
                positionInCampusTour = i+1;
            }

        }
        System.out.println("positionInCampusTour : "+positionInCampusTour);
        List<SKCoordinate> completedCourse = university.getTourPath().subList(0,positionInCampusTour);
        addPlolyLine(completedCourse);
    }


    public void addAllBuildingAnnotations() {

        SKAnnotation annotation = new SKAnnotation(0);
        annotation
                .setAnnotationType(SKAnnotation.SK_ANNOTATION_TYPE_GREEN);
        annotation.setLocation(university.getUniversityLocation());
        mapView.addAnnotation(annotation, SKAnimationSettings.ANIMATION_NONE);

        mapView.animateToLocation(university.getUniversityLocation(), 0);
        buildingAnnotations = new ArrayList<>(university.getBuildings().size());
        mapView.setZoom(15.5f);
        addBuildingAnnotations();
        addAnnotationsToMapView();
    }



    @Override
    public void onActionPan() {

    }

    @Override
    public void onActionZoom() {

    }

    @Override
    protected void onPause() {
        super.onPause();
        mapHolder.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mapHolder.onResume();
        SKMapsApplication.setActiveActivity(2);
    }

    @Override
    public void onSurfaceCreated(SKMapViewHolder skMapViewHolder) {
        mapHolder = skMapViewHolder;
        mapView= mapHolder.getMapSurfaceView();
        mapView.clearAllOverlays();
        mapView.deleteAllAnnotationsAndCustomPOIs();
        try {
            SKMapsApplication.getNavigationmanager().stopNavigation();
        }catch(NullPointerException e){

        }
        addAllBuildingAnnotations();


    }

    public void addAnnotationsToMapView(){
        for(SKAnnotation annotation: buildingAnnotations){
            mapView.addAnnotation(annotation,SKAnimationSettings.ANIMATION_NONE);
        }
    }

    public void addBuildingAnnotations(){

        buildingAnnotations.clear();
        int tag = 1;
        for (Building b : university.getBuildings()) {
            SKAnnotation sk = new SKAnnotation(tag);
            sk.setAnnotationType(SKAnnotation.SK_ANNOTATION_TYPE_BLUE);
            sk.setLocation(b.getBuildingCoordinates());
            buildingAnnotations.add(sk);
            System.out.println("Building Annotatoins size :" + buildingAnnotations.size());
            tag++;
        }
    }
    @Override
    public void onMapRegionChanged(SKCoordinateRegion skCoordinateRegion) {

    }

    @Override
    public void onMapRegionChangeStarted(SKCoordinateRegion skCoordinateRegion) {

    }

    @Override
    public void onMapRegionChangeEnded(SKCoordinateRegion skCoordinateRegion) {

    }

    @Override
    public void onDoubleTap(SKScreenPoint skScreenPoint) {

    }

    @Override
    public void onSingleTap(SKScreenPoint skScreenPoint) {

    }

    @Override
    public void onRotateMap() {

    }

    @Override
    public void onLongPress(SKScreenPoint skScreenPoint) {

    }

    @Override
    public void onInternetConnectionNeeded() {

    }

    @Override
    public void onMapActionDown(SKScreenPoint skScreenPoint) {

    }

    @Override
    public void onMapActionUp(SKScreenPoint skScreenPoint) {

    }

    @Override
    public void onPOIClusterSelected(SKPOICluster skpoiCluster) {

    }

    @Override
    public void onMapPOISelected(SKMapPOI skMapPOI) {

    }
public void showBuildingDetailsInNewActivity(int position){

//    String fileName = SKMapsApplication.getUniversity().getBuildings().get(position).getBuildingName().replace(" ","");
    Intent galleryIntent = new Intent(this, Gallery.class);
    if(position == -1){
        galleryIntent.putExtra("name", SKMapsApplication.university.getUniversityName());
    }

    else{
        galleryIntent.putExtra("name", SKMapsApplication.university.getBuildings().get(position).getBuildingName());
    }
    galleryIntent.putExtra("position",position);
    startActivity(galleryIntent);


}
    @Override
    public void onAnnotationSelected(SKAnnotation skAnnotation) {
//        final Dialog dialog = new Dialog(VirtualTourActivity.this);
//        dialog.setContentView(R.layout.gallery_view);
        int position = skAnnotation.getUniqueID() - 1;
        showBuildingDetailsInNewActivity(position);
//        //   mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(university.getBuildings().get(position).getBuildingCoordinates(),18.0f));
//        if (position == -1)
//            dialog.setTitle(university.getUniversityName());
//        if (position >= 0)
//            dialog.setTitle(university.getBuildings().get(position).getBuildingName());
//        TextView title = (TextView) dialog.findViewById(R.id.dialogue_Title);
//
//        if (position == -1)
//            title.setText(university.getUniversityName());
//        if (position >= 0)
//            title.setText(university.getBuildings().get(position).getBuildingName());
//
//        dialog.show();
//        LinearLayout videoLayout = (LinearLayout) dialog.findViewById(R.id.video_slider);
//
//        for (int i = 0; i < 3; i++) {
//            ImageView imageView = new ImageView(VirtualTourActivity.this);
//            imageView.setId(i);
//            imageView.setPadding(2, 2, 2, 2);
//            imageView.setImageBitmap(BitmapFactory.decodeResource(
//                    getResources(), R.drawable.novideo));
//            imageView.setScaleType(ImageView.ScaleType.CENTER);
//            videoLayout.addView(imageView);
//        }
//
//        LinearLayout audioLayout = (LinearLayout) dialog.findViewById(R.id.audio_slider);
//
//        for (int i = 0; i < 3; i++) {
//            ImageView imageView = new ImageView(VirtualTourActivity.this);
//            imageView.setId(i);
//            imageView.setPadding(2, 2, 2, 2);
//            imageView.setImageBitmap(BitmapFactory.decodeResource(
//                    getResources(), R.drawable.noaudio));
//            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
//            audioLayout.addView(imageView);
//        }
//
//
//        LinearLayout ImagesLayout = (LinearLayout) dialog.findViewById(R.id.images_slider);
//        for (int i = 0; i < 3; i++) {
//            ImageView imageView = new ImageView(VirtualTourActivity.this);
//            imageView.setId(i);
//            imageView.setPadding(2, 2, 2, 2);
//            imageView.setImageBitmap(BitmapFactory.decodeResource(
//                    getResources(), R.drawable.noimages));
//            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
//            ImagesLayout.addView(imageView);
//        }
//
//
//        Button dialogButton = (Button) dialog.findViewById(R.id.dialogue_ok_button);
//        // if button is clicked, close the custom dialog
//        dialogButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                dialog.dismiss();
//            }
//        });

    }

    @Override
    public void onCustomPOISelected(SKMapCustomPOI skMapCustomPOI) {

    }

    @Override
    public void onCompassSelected() {

    }

    @Override
    public void onCurrentPositionSelected() {

    }

    @Override
    public void onObjectSelected(int i) {

    }

    @Override
    public void onInternationalisationCalled(int i) {

    }

    @Override
    public void onBoundingBoxImageRendered(int i) {

    }

    @Override
    public void onGLInitializationError(String s) {

    }

    @Override
    public void onScreenshotReady(Bitmap bitmap) {

    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onStop() {
        super.onStop();
    }
}
