package com.skmapstutorial.Application.Fragments;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.skmapstutorial.R;

import java.util.ArrayList;

/**
 * Created by mkrao on 3/28/2017.
 */

public class AudioAdapter extends BaseAdapter {
    private ArrayList<String>  listData;
    private LayoutInflater layoutInflater;

    public AudioAdapter(Context context, ArrayList<String> listData) {
        this.listData = listData;
        layoutInflater = LayoutInflater.from(context);
    }


    @Override
    public int getCount() {
        return listData.size();
    }
    @Override
    public Object getItem(int position) {
        return listData.get(position);
    }


    @Override
    public long getItemId(int position) {
        return position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {

            holder = new ViewHolder();
            convertView = layoutInflater.inflate(R.layout.image_layout_list_item, null);
            holder.imageView = (ImageView) convertView.findViewById(R.id.image_in_adapter);

                       holder.imageView.setImageResource(R.drawable.media_play);




            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }


        return convertView;
    }

    static class ViewHolder {

        ImageView imageView;
    }



}
