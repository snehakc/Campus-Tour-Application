package com.skmapstutorial.Application.Fragments;


import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.skmapstutorial.R;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class Audio extends Fragment {

    String fileName;
    int numberOfAudioFiles;
    boolean hasAudio;
    LinearLayout audioImageHolder;
    MediaPlayer mediaPlayer = new MediaPlayer();
    ArrayList<String> listItems = new ArrayList<>();
    ListView lv;
    View v;
    boolean isPaused = false;
    AudioAdapter audioAdapter;

    public Audio() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        listItems.clear();
        View v = inflater.inflate(R.layout.fragment_audio, container, false);
        this.v = v;
        fileName = ((Gallery) getActivity()).getBuildignName().replace(" ", "");
        lv = (ListView) v.findViewById(R.id.audio_list_view);

        audioAdapter = new AudioAdapter(getActivity(), listItems);
        // audioImageHolder = (LinearLayout) v.findViewById(R.id.audio_images_holder);
        try {
            numberOfAudioFiles = (new File(getActivity().getApplicationContext().getExternalFilesDir(null) + "/" + fileName + "/Audio")).listFiles().length;
        } catch (NullPointerException e) {
            numberOfAudioFiles = 0;
        }
        hasAudio = numberOfAudioFiles > 0 ? true : false;
        if (hasAudio) {
            System.out.println("Has videos");
            for (int i = 1; i <= numberOfAudioFiles; i++) {
                System.out.println("Audio FIles Being Created: "+ i);
                System.out.println("Files in Fragmets: " + getActivity().getApplicationContext().getExternalFilesDir(null) + "/" + fileName + "/Audio/" + i + ".jpg");
                // File imgFile = new File(getActivity().getApplicationContext().getExternalFilesDir(null) + "/" + fileName + "/Audio/" + i + ".jpg");

                System.out.println("Files in Fragmets: " + getActivity().getApplicationContext().getExternalFilesDir(null) + "/" + fileName + "/Images/" + i + ".jpg");
                File imgFile = new File(getActivity().getApplicationContext().getExternalFilesDir(null) + "/" + fileName + "/Images/" + i + ".jpg");
                listItems.add(fileName);


                ImageView imageView = new ImageView((Gallery) getActivity());
                // imageView.setId(i);
                imageView.setPadding(2, 2, 2, 2);
                imageView.setId(i * 300);
                imageView.setImageResource(R.drawable.media_play);
                imageView.setScaleType(ImageView.ScaleType.FIT_XY);
                //  audioImageHolder.addView(imageView);
//                imageView.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        playAudio(fileName,v.getId()/300,(ImageView) v);
//                    }
//                });
                listItems.add(fileName);

            }
            lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View v, int position, long id) {

                    playAudio(listItems.get(position), position,v);
                }
            });
            lv.setAdapter(audioAdapter);
        } else {
            displayNoFiles(v);
        }
        return v;
    }

    public void playAudio(String fileName, int i, View v) {
        ImageView iInAudio = (ImageView) v.findViewById(R.id.image_in_adapter);
        try {

            if (mediaPlayer.isPlaying()) {

                iInAudio.setImageResource(R.drawable.media_play);
                mediaPlayer.pause();
                System.out.println("Pausing the audio");
                isPaused = true;
                return;
            }
            else  if (isPaused) {
                mediaPlayer.start();

                iInAudio.setImageResource(R.drawable.stop);
                isPaused = false;
            } else {
                String audioFile = getActivity().getApplicationContext().getExternalFilesDir(null) + "/" + fileName + "/Audio/" + i + ".3gpp"; // initialize Uri here
                mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
                Uri uri = Uri.parse(audioFile);
                mediaPlayer.setDataSource(getActivity(), uri);
                mediaPlayer.prepare();
                mediaPlayer.start();
                iInAudio.setImageResource(R.drawable.stop);
            }

        } catch (IOException e) {
            System.out.println("IO Exception Caught in Audio files");

        }
    }

    public void displayNoFiles(View v) {
        ((ImageView) v.findViewById(R.id.no_audio_placeholder)).setVisibility(View.VISIBLE);
        ((ListView) v.findViewById(R.id.audio_list_view)).setVisibility(View.GONE);
    }
}
